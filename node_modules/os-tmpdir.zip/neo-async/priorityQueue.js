'use stirct';

module.exports = require('./async').priorityQueue;
