"use strict";

module.exports = Math.pow(2, 53) - 1;
