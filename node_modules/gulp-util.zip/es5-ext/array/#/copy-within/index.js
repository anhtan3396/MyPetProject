"use strict";

module.exports = require("./is-implemented")()
		? Array.prototype.copyWithin : require("./shim");
