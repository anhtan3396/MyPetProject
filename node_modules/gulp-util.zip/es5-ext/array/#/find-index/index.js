"use strict";

module.exports = require("./is-implemented")()
		? Array.prototype.findIndex : require("./shim");
