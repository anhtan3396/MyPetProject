<a name="2.3.0"></a>
# [2.3.0](https://github.com/michael-ciniawsky/postcss-load-plugins/compare/v2.2.0...v2.3.0) (2017-02-13)


### Features

* **index:** Allow extensions for .postcssrc ([65cc0d0](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/65cc0d0))



<a name="2.2.0"></a>
# 2.2.0 (2017-01-11)


### Features

* **index:** expose config file ([c643172](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/c643172))
* **index:** improve error handling ([f3a4048](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/f3a4048))
* **lib:** improve error handling ([a64bb03](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/a64bb03))



<a name="2.1.0"></a>
# 2.1.0 (2016-12-05)


### Bug Fixes

* **index:** set NODE_ENV if undefined ([920f806](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/920f806))
* **index:** support node v0.12 ([e31fab3](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/e31fab3))
* **lib/plugins:** support node v0.12 ([c440e6b](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/c440e6b))
* **loadPlugins:** add object-assign polyfill ([acd3f84](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/acd3f84))
* **plugins:** check for plugin.default ([024e8c7](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/024e8c7))

### Features

* function support, jsdoc, cleanups ([f637d60](https://github.com/michael-ciniawsky/postcss-load-plugins/commit/f637d60))
