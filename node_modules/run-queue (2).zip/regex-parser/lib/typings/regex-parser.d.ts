declare module 'regex-parser' {
	function Parse(regexString: string): RegExp;

	export = Parse;
}
