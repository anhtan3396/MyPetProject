// @flow

import createWebStorage from './createWebStorage'

export default createWebStorage('session')
