// @noflow
/* eslint-disable */

import { AsyncStorage } from 'react-native'

export default AsyncStorage
