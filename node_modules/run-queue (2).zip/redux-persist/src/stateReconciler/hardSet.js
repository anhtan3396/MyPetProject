// @flow

/*
  hardSet: 
    - hard set incoming state
*/

export default function hardSet<State: Object>(inboundState: State): State {
  return inboundState
}
