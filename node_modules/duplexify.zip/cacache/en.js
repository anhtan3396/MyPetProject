'use strict'

module.exports = require('./locales/en.js')
