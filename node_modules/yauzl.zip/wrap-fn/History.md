
0.1.5 / 2016-02-13
==================

  * fix note
  * deprecation note.

0.1.4 / 2015-01-21
==================

  * slim down the package
  * Use `files` property in package.json
  * Rename component dependency `visionmedia/co` to `tj/co`

0.1.3 / 2015-01-16
==================

  * fix return bug

0.1.2 / 2015-01-16
==================

  * catch uncaught synchronous errors in async functions

0.1.1 / 2014-09-24
==================

* Add "scripts" field in `component.json`

0.1.0 / 2014-09-17
==================

 * Promises, synchronous errors and tests

0.0.2 / 2014-08-31
==================

 * use return value on sync functions

0.0.1 / 2010-01-03
==================

  * Initial release
