export { default, FeedProps } from './Feed';
