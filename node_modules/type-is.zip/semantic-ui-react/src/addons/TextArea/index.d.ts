export { default, TextAreaProps } from './TextArea';
