export { default, ResponsiveProps, ResponsiveOnUpdateData, ResponsiveWidthShorthand } from './Responsive';
