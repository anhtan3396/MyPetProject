export { default, PaginationProps } from './Pagination';
