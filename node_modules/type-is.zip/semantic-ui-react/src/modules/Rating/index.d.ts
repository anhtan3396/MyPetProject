export { default, RatingProps } from './Rating';
