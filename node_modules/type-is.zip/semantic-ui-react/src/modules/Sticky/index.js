export default from './Sticky'
