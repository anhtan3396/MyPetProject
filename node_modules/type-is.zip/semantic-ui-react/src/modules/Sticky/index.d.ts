export { default, StickyProps } from './Sticky';
