export { default, EmbedProps } from './Embed';
