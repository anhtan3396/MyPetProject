export { default, SearchProps, SearchResultData } from './Search';
