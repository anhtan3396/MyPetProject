export { default, DimmerProps } from './Dimmer';
