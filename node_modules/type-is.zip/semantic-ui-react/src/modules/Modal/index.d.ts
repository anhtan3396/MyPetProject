export { default, ModalProps } from './Modal';
