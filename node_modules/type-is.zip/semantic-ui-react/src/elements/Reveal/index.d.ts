export { default, RevealProps } from './Reveal';
