export { default, SegmentProps } from './Segment';
