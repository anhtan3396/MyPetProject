export default from './Label'
