export { default, LabelProps } from './Label';
