export default from './Image'
